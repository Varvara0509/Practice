package com.example.tracking;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProjectListActivity extends AppCompatActivity implements ProjectAdapter.OnProjectActionListener {

    private RecyclerView recyclerView;
    private ProjectAdapter adapter;
    private List<Project> projectList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_list);

        // Настройка Toolbar с кнопкой "Назад"
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Просмотр проектов");
        }

        // Инициализация RecyclerView
        recyclerView = findViewById(R.id.recyclerViewProjects);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Тестовые данные
        projectList = new ArrayList<>();
        projectList.add(new Project(1, "Разработка мобильного приложения",
                "Создание приложения для учета времени", "01.02.2026", "30.06.2026", 500000));
        projectList.add(new Project(2, "Обновление сайта",
                "Редизайн и новая функциональность", "10.01.2026", "15.03.2026", 200000));
        projectList.add(new Project(3, "Тестирование системы",
                "Написание тестов и отладка", "01.03.2026", "30.04.2026", 150000));

        adapter = new ProjectAdapter(projectList, this);
        recyclerView.setAdapter(adapter);
    }

    // Обработка кнопки "Назад" на Toolbar
    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Реализация методов интерфейса OnProjectActionListener

    @Override
    public void onEdit(Project project) {
        // Здесь можно показать диалог редактирования
        // Для простоты показываем Toast
        Toast.makeText(this, "Редактирование проекта: " + project.getName(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDelete(Project project) {
        // Диалог подтверждения удаления
        new AlertDialog.Builder(this)
                .setTitle("Удаление проекта")
                .setMessage("Вы уверены, что хотите удалить проект \"" + project.getName() + "\"?")
                .setPositiveButton("Удалить", (dialog, which) -> {
                    // Удаляем из списка и уведомляем адаптер
                    projectList.remove(project);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(this, "Проект удален", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    @Override
    public void onItemClick(Project project) {
        // Диалог с деталями проекта
        new AlertDialog.Builder(this)
                .setTitle(project.getName())
                .setMessage("Описание: " + project.getDescription() +
                        "\nДата начала: " + project.getStartDate() +
                        "\nДата окончания: " + project.getEndDate() +
                        "\nБюджет: " + project.getBudget() + " руб.")
                .setPositiveButton("OK", null)
                .show();
    }
}