package com.example.tracking;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.ViewHolder> {

    private List<Project> projects;
    private OnProjectActionListener listener;

    // Интерфейс для обратного вызова
    public interface OnProjectActionListener {
        void onEdit(Project project);
        void onDelete(Project project);
        void onItemClick(Project project);
    }

    public ProjectAdapter(List<Project> projects, OnProjectActionListener listener) {
        this.projects = projects;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_project, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Project project = projects.get(position);

        holder.tvName.setText(project.getName());
        holder.tvDates.setText(project.getStartDate() + " - " + project.getEndDate());
        holder.tvBudget.setText("Бюджет: " + project.getBudget());

        // Обработка клика на элемент (всю карточку)
        holder.itemView.setOnClickListener(v -> listener.onItemClick(project));

        // Обработка кнопки редактирования
        holder.btnEdit.setOnClickListener(v -> listener.onEdit(project));

        // Обработка кнопки удаления
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(project));
    }

    @Override
    public int getItemCount() {
        return projects.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDates, tvBudget;
        ImageButton btnEdit, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvProjectName);
            tvDates = itemView.findViewById(R.id.tvProjectDates);
            tvBudget = itemView.findViewById(R.id.tvProjectBudget);
            btnEdit = itemView.findViewById(R.id.btnEditProject);
            btnDelete = itemView.findViewById(R.id.btnDeleteProject);
        }
    }
}