package com.example.tracking;

public class TimeRecord {
    private int id;
    private String employeeName;
    private String taskName;
    private String date;
    private double hours;
    private String description;
    private String approvalStatus; // "На рассмотрении", "Утверждено", "Отклонено"
    private String notificationStatus; // "Не отправлено", "Отправлено"

    public TimeRecord(int id, String employeeName, String taskName, String date,
                      double hours, String description, String approvalStatus,
                      String notificationStatus) {
        this.id = id;
        this.employeeName = employeeName;
        this.taskName = taskName;
        this.date = date;
        this.hours = hours;
        this.description = description;
        this.approvalStatus = approvalStatus;
        this.notificationStatus = notificationStatus;
    }

    // Геттеры и сеттеры
    public int getId() { return id; }
    public String getEmployeeName() { return employeeName; }
    public String getTaskName() { return taskName; }
    public String getDate() { return date; }
    public double getHours() { return hours; }
    public String getDescription() { return description; }
    public String getApprovalStatus() { return approvalStatus; }
    public String getNotificationStatus() { return notificationStatus; }

    public void setApprovalStatus(String approvalStatus) { this.approvalStatus = approvalStatus; }
    public void setNotificationStatus(String notificationStatus) { this.notificationStatus = notificationStatus; }
}