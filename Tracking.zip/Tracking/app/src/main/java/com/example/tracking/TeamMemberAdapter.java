package com.example.tracking;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;

public class TeamMemberAdapter extends RecyclerView.Adapter<TeamMemberAdapter.ViewHolder> {

    private List<Employee> members;
    private OnMemberActionListener listener;

    public interface OnMemberActionListener {
        void onEdit(Employee employee);
        void onDelete(Employee employee);
        void onViewTasks(Employee employee);
    }

    public TeamMemberAdapter(List<Employee> members, OnMemberActionListener listener) {
        this.members = members;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_team_member, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Employee member = members.get(position);
        holder.tvName.setText(member.getFullName());
        holder.tvRole.setText(member.getRole());
        holder.tvEmail.setText(member.getEmail());
        holder.tvTasksCount.setText("Задач: 3"); // заглушка
        holder.tvHours.setText("Часов: 12"); // заглушка

        holder.btnEdit.setOnClickListener(v -> listener.onEdit(member));
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(member));
        holder.btnViewTasks.setOnClickListener(v -> listener.onViewTasks(member));
    }

    @Override
    public int getItemCount() {
        return members.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvRole, tvEmail, tvTasksCount, tvHours;
        MaterialButton btnEdit, btnDelete, btnViewTasks;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvRole = itemView.findViewById(R.id.tvRole);
            tvEmail = itemView.findViewById(R.id.tvEmail);
            tvTasksCount = itemView.findViewById(R.id.tvTasksCount);
            tvHours = itemView.findViewById(R.id.tvHours);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnViewTasks = itemView.findViewById(R.id.btnViewTasks);
        }
    }
}