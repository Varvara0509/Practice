package com.example.tracking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class EmployeeMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_menu);

        MaterialButton btnMyProjects = findViewById(R.id.buttonMyProjects);
        MaterialButton btnMyTasks = findViewById(R.id.buttonMyTasks);
        MaterialButton btnPersonalStats = findViewById(R.id.buttonPersonalStats);
        MaterialButton btnLogout = findViewById(R.id.buttonLogout);

        btnMyProjects.setOnClickListener(v ->
                openPlaceholder("Мои проекты")
        );

        btnMyTasks.setOnClickListener(v ->
                openPlaceholder("Мои задачи")
        );

        btnPersonalStats.setOnClickListener(v ->
                openPlaceholder("Личная статистика")
        );

        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(EmployeeMenuActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void openPlaceholder(String title) {
        Intent intent = new Intent(EmployeeMenuActivity.this, PlaceholderActivity.class);
        intent.putExtra("title", title);
        startActivity(intent);
    }
}