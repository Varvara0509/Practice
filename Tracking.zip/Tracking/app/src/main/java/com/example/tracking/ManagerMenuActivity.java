package com.example.tracking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class ManagerMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_menu);

        MaterialButton btnProjects = findViewById(R.id.buttonProjects);
        MaterialButton btnTimeApproval = findViewById(R.id.buttonTimeApproval);
        MaterialButton btnReports = findViewById(R.id.buttonReports);
        MaterialButton btnTeamManagement = findViewById(R.id.buttonTeamManagement);
        MaterialButton btnLogout = findViewById(R.id.buttonLogout);

        btnProjects.setOnClickListener(v -> {
            Intent intent = new Intent(ManagerMenuActivity.this, ProjectListActivity.class);
            startActivity(intent);
        });

        btnTimeApproval.setOnClickListener(v -> {
            Intent intent = new Intent(ManagerMenuActivity.this, TimeApprovalActivity.class);
            startActivity(intent);
        });

        btnReports.setOnClickListener(v -> {
            Intent intent = new Intent(ManagerMenuActivity.this, AnalyticsReportsActivity.class);
            startActivity(intent);
        });

        btnTeamManagement.setOnClickListener(v -> {
            Intent intent = new Intent(ManagerMenuActivity.this, TeamManagementActivity.class);
            startActivity(intent);
        });
        btnLogout.setOnClickListener(v -> {
            // Возврат на экран входа
            Intent intent = new Intent(ManagerMenuActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void openPlaceholder(String title) {

        Intent intent = new Intent(ManagerMenuActivity.this, PlaceholderActivity.class);
        intent.putExtra("title", title);
        startActivity(intent);
    }
}