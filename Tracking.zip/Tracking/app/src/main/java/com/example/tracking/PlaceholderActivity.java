package com.example.tracking;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class PlaceholderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placeholder);

        TextView textView = findViewById(R.id.textViewPlaceholder);
        MaterialButton btnBack = findViewById(R.id.buttonBack);

        String title = getIntent().getStringExtra("title");
        if (title != null) {
            textView.setText(title);
        }

        btnBack.setOnClickListener(v -> finish()); // просто закрываем текущую активность
    }
}