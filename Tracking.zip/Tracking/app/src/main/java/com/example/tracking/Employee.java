package com.example.tracking;

public class Employee {
    private int id;
    private String fullName;
    private String role; // "Сотрудник" или "Руководитель"
    private String email;

    public Employee(int id, String fullName, String role, String email) {
        this.id = id;
        this.fullName = fullName;
        this.role = role;
        this.email = email;
    }

    // Геттеры
    public int getId() { return id; }
    public String getFullName() { return fullName; }
    public String getRole() { return role; }
    public String getEmail() { return email; }
}