package com.example.tracking;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import java.util.ArrayList;
import java.util.List;

public class TimeApprovalActivity extends AppCompatActivity implements TimeRecordAdapter.OnRecordActionListener {

    private RecyclerView recyclerView;
    private TimeRecordAdapter adapter;
    private List<TimeRecord> allRecords;
    private List<TimeRecord> displayedRecords;
    private MaterialAutoCompleteTextView spinnerFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_approval);

        recyclerView = findViewById(R.id.recyclerViewTimeRecords);
        spinnerFilter = findViewById(R.id.spinnerStatusFilter);

        // Настройка RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Тестовые данные
        allRecords = new ArrayList<>();
        allRecords.add(new TimeRecord(1, "Иванов Иван", "Разработка модуля", "15.02.2026", 4.5,
                "Написал код авторизации", "На рассмотрении", "Не отправлено"));
        allRecords.add(new TimeRecord(2, "Петров Петр", "Тестирование", "15.02.2026", 3.0,
                "Провел тесты", "Утверждено", "Не отправлено"));
        allRecords.add(new TimeRecord(3, "Сидорова Анна", "Документация", "14.02.2026", 2.0,
                "Обновил README", "Отклонено", "Отправлено"));
        allRecords.add(new TimeRecord(4, "Иванов Иван", "Исправление багов", "14.02.2026", 5.0,
                "Исправил критический баг", "На рассмотрении", "Не отправлено"));

        displayedRecords = new ArrayList<>(allRecords);
        adapter = new TimeRecordAdapter(displayedRecords, this);
        recyclerView.setAdapter(adapter);

        // Настройка фильтра
        String[] statuses = {"Все статусы", "На рассмотрении", "Утверждено", "Отклонено"};
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, statuses);
        spinnerFilter.setAdapter(arrayAdapter);
        spinnerFilter.setText("Все статусы", false);

        spinnerFilter.setOnItemClickListener((parent, view, position, id) -> {
            String selected = (String) parent.getItemAtPosition(position);
            filterRecords(selected);
        });
    }

    private void filterRecords(String status) {
        displayedRecords.clear();
        if (status.equals("Все статусы")) {
            displayedRecords.addAll(allRecords);
        } else {
            for (TimeRecord record : allRecords) {
                if (record.getApprovalStatus().equals(status)) {
                    displayedRecords.add(record);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onApprove(TimeRecord record) {
        record.setApprovalStatus("Утверждено");
        adapter.notifyDataSetChanged();
        Toast.makeText(this, "Запись утверждена", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onReject(TimeRecord record) {
        record.setApprovalStatus("Отклонено");
        adapter.notifyDataSetChanged();
        Toast.makeText(this, "Запись отклонена", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSendNotification(TimeRecord record) {
        if (!record.getApprovalStatus().equals("На рассмотрении") && record.getNotificationStatus().equals("Не отправлено")) {
            record.setNotificationStatus("Отправлено");
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Уведомление отправлено сотруднику", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Нельзя отправить уведомление", Toast.LENGTH_SHORT).show();
        }
    }
}