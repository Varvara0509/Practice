package com.example.tracking; // замените на свой package

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText editTextLogin, editTextPassword;
    private MaterialButton buttonLogin;

    // Тестовые данные
    private final String MANAGER_LOGIN = "varya";
    private final String EMPLOYEE_LOGIN = "ivan";
    private final String CORRECT_PASSWORD = "123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initViews();
        setupListeners();
    }

    private void initViews() {
        editTextLogin = findViewById(R.id.editTextLogin);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
    }

    private void setupListeners() {
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptLogin();
            }
        });
    }

    private void attemptLogin() {
        String login = editTextLogin.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (login.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(CORRECT_PASSWORD)) {
            Toast.makeText(this, "Неверный пароль", Toast.LENGTH_SHORT).show();
            return;
        }

        // Определение роли и переход в соответствующее меню
        Intent intent;
        if (login.equals(MANAGER_LOGIN)) {
            intent = new Intent(LoginActivity.this, ManagerMenuActivity.class);
        } else if (login.equals(EMPLOYEE_LOGIN)) {
            intent = new Intent(LoginActivity.this, EmployeeMenuActivity.class);
        } else {
            Toast.makeText(this, "Пользователь не найден", Toast.LENGTH_SHORT).show();
            return;
        }

        intent.putExtra("login", login); // можно передать логин для приветствия
        startActivity(intent);
        finish(); // закрываем LoginActivity, чтобы нельзя было вернуться назад
    }
}