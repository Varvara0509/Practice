package com.example.tracking;

public class Project {
    private int id;
    private String name;
    private String description;
    private String startDate;
    private String endDate;
    private double budget;

    public Project(int id, String name, String description, String startDate, String endDate, double budget) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.budget = budget;
    }

    // Геттеры и сеттеры
    public int getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getStartDate() { return startDate; }
    public String getEndDate() { return endDate; }
    public double getBudget() { return budget; }

    public void setName(String name) { this.name = name; }
    public void setDescription(String description) { this.description = description; }
    public void setStartDate(String startDate) { this.startDate = startDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }
    public void setBudget(double budget) { this.budget = budget; }
}