package com.example.tracking;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

public class AnalyticsReportsActivity extends AppCompatActivity {

    private MaterialAutoCompleteTextView spinnerReportType;
    private LinearLayout layoutEmployeeLoad, layoutTimeStats;
    private MaterialButton btnGenerateReport;
    private TextView tvReportResult;

    // Элементы для отчета по загрузке сотрудников
    private MaterialAutoCompleteTextView spinnerEmployee;
    private EditText editDays;

    // Элементы для отчета по статистике времени
    private MaterialAutoCompleteTextView spinnerProjectStats, spinnerGroupBy;
    private EditText editStartDate, editEndDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analytics_reports);

        initViews();
        setupSpinners();
        setupListeners();
    }

    private void initViews() {
        spinnerReportType = findViewById(R.id.spinnerReportType);
        layoutEmployeeLoad = findViewById(R.id.layoutEmployeeLoad);
        layoutTimeStats = findViewById(R.id.layoutTimeStats);
        btnGenerateReport = findViewById(R.id.btnGenerateReport);
        tvReportResult = findViewById(R.id.tvReportResult);

        // Дочерние элементы
        spinnerEmployee = findViewById(R.id.spinnerEmployee);
        editDays = findViewById(R.id.editDays);
        spinnerProjectStats = findViewById(R.id.spinnerProjectStats);
        spinnerGroupBy = findViewById(R.id.spinnerGroupBy);
        editStartDate = findViewById(R.id.editStartDate);
        editEndDate = findViewById(R.id.editEndDate);
    }

    private void setupSpinners() {
        // Типы отчетов
        String[] reportTypes = {"Загрузка сотрудников", "Статистика по времени"};
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, reportTypes);
        spinnerReportType.setAdapter(typeAdapter);
        spinnerReportType.setText(reportTypes[0], false);

        // Сотрудники
        String[] employees = {"Все сотрудники", "Иванов Иван", "Петров Петр"};
        ArrayAdapter<String> empAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, employees);
        spinnerEmployee.setAdapter(empAdapter);
        spinnerEmployee.setText(employees[0], false);

        // Проекты для статистики
        String[] projects = {"Все проекты", "Проект А", "Проект Б"};
        ArrayAdapter<String> projAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, projects);
        spinnerProjectStats.setAdapter(projAdapter);
        spinnerProjectStats.setText(projects[0], false);

        // Группировка
        String[] groupBy = {"по дням", "по неделям", "по месяцам"};
        ArrayAdapter<String> groupAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, groupBy);
        spinnerGroupBy.setAdapter(groupAdapter);
        spinnerGroupBy.setText(groupBy[0], false);
    }

    private void setupListeners() {
        spinnerReportType.setOnItemClickListener((parent, view, position, id) -> {
            String selected = (String) parent.getItemAtPosition(position);
            if (selected.equals("Загрузка сотрудников")) {
                layoutEmployeeLoad.setVisibility(View.VISIBLE);
                layoutTimeStats.setVisibility(View.GONE);
            } else {
                layoutEmployeeLoad.setVisibility(View.GONE);
                layoutTimeStats.setVisibility(View.VISIBLE);
            }
        });

        btnGenerateReport.setOnClickListener(v -> generateReport());

    }

    private void generateReport() {
        String reportType = spinnerReportType.getText().toString();
        StringBuilder result = new StringBuilder();

        if (reportType.equals("Загрузка сотрудников")) {
            String employee = spinnerEmployee.getText().toString();
            String days = editDays.getText().toString();
            if (days.isEmpty()) days = "0";
            result.append("Отчет по загрузке сотрудников\n");
            result.append("Сотрудник: ").append(employee).append("\n");
            result.append("Период: ").append(days).append(" дней\n");
            result.append("Общее количество часов: 42\n");
            result.append("Выполненные задачи: 7\n");
            result.append("Средняя дневная нагрузка: 6 ч");
        } else {
            String project = spinnerProjectStats.getText().toString();
            String group = spinnerGroupBy.getText().toString();
            String start = editStartDate.getText().toString();
            String end = editEndDate.getText().toString();
            result.append("Отчет по статистике времени\n");
            result.append("Проект: ").append(project).append("\n");
            result.append("Группировка: ").append(group).append("\n");
            result.append("Период: ").append(start).append(" - ").append(end).append("\n");
            result.append("Общая статистика: 120 часов, 15 задач\n");
            result.append("Статистика по сотрудникам: ...\n");
            result.append("Статистика по статусам: ...");
        }

        tvReportResult.setText(result.toString());
        tvReportResult.setVisibility(View.VISIBLE);
    }
}