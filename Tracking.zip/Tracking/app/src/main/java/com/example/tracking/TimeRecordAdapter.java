package com.example.tracking;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;

public class TimeRecordAdapter extends RecyclerView.Adapter<TimeRecordAdapter.ViewHolder> {

    private List<TimeRecord> records;
    private OnRecordActionListener listener;

    public interface OnRecordActionListener {
        void onApprove(TimeRecord record);
        void onReject(TimeRecord record);
        void onSendNotification(TimeRecord record);
    }

    public TimeRecordAdapter(List<TimeRecord> records, OnRecordActionListener listener) {
        this.records = records;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_time_record, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TimeRecord record = records.get(position);
        holder.tvEmployee.setText(record.getEmployeeName());
        holder.tvTask.setText(record.getTaskName());
        holder.tvDate.setText(record.getDate());
        holder.tvHours.setText(String.valueOf(record.getHours()) + " ч");
        holder.tvDescription.setText(record.getDescription());
        holder.tvApprovalStatus.setText(record.getApprovalStatus());
        holder.tvNotificationStatus.setText(record.getNotificationStatus());

        // Меняем цвет статуса
        if (record.getApprovalStatus().equals("Утверждено")) {
            holder.tvApprovalStatus.setTextColor(holder.itemView.getContext().getColor(android.R.color.holo_green_dark));
        } else if (record.getApprovalStatus().equals("Отклонено")) {
            holder.tvApprovalStatus.setTextColor(holder.itemView.getContext().getColor(android.R.color.holo_red_dark));
        } else {
            holder.tvApprovalStatus.setTextColor(holder.itemView.getContext().getColor(android.R.color.black));
        }

        // Доступность кнопок зависит от статуса
        boolean isPending = record.getApprovalStatus().equals("На рассмотрении");
        holder.btnApprove.setEnabled(isPending);
        holder.btnReject.setEnabled(isPending);

        // Кнопка уведомления доступна, если статус утверждения не "На рассмотрении" и уведомление не отправлено
        boolean canNotify = !record.getApprovalStatus().equals("На рассмотрении") &&
                record.getNotificationStatus().equals("Не отправлено");
        holder.btnSendNotification.setEnabled(canNotify);

        holder.btnApprove.setOnClickListener(v -> listener.onApprove(record));
        holder.btnReject.setOnClickListener(v -> listener.onReject(record));
        holder.btnSendNotification.setOnClickListener(v -> listener.onSendNotification(record));
    }

    @Override
    public int getItemCount() {
        return records.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvEmployee, tvTask, tvDate, tvHours, tvDescription, tvApprovalStatus, tvNotificationStatus;
        MaterialButton btnApprove, btnReject, btnSendNotification;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEmployee = itemView.findViewById(R.id.tvEmployee);
            tvTask = itemView.findViewById(R.id.tvTask);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvHours = itemView.findViewById(R.id.tvHours);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvApprovalStatus = itemView.findViewById(R.id.tvApprovalStatus);
            tvNotificationStatus = itemView.findViewById(R.id.tvNotificationStatus);
            btnApprove = itemView.findViewById(R.id.btnApprove);
            btnReject = itemView.findViewById(R.id.btnReject);
            btnSendNotification = itemView.findViewById(R.id.btnSendNotification);
        }
    }
}