package com.example.tracking;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import java.util.ArrayList;
import java.util.List;

public class TeamManagementActivity extends AppCompatActivity implements TeamMemberAdapter.OnMemberActionListener {

    private RecyclerView recyclerView;
    private TeamMemberAdapter adapter;
    private List<Employee> teamMembers;
    private MaterialAutoCompleteTextView spinnerProject;
    private MaterialButton btnLoadTeam, btnAddMember;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_management);

        recyclerView = findViewById(R.id.recyclerViewTeam);
        spinnerProject = findViewById(R.id.spinnerProject);
        btnLoadTeam = findViewById(R.id.btnLoadTeam);
        btnAddMember = findViewById(R.id.btnAddMember);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Тестовые данные сотрудников
        teamMembers = new ArrayList<>();
        teamMembers.add(new Employee(1, "Иванов Иван", "Сотрудник", "ivanov@mail.com"));
        teamMembers.add(new Employee(2, "Петрова Мария", "Сотрудник", "petrova@mail.com"));
        teamMembers.add(new Employee(3, "Сидоров Петр", "Сотрудник", "sidorov@mail.com"));

        adapter = new TeamMemberAdapter(teamMembers, this);
        recyclerView.setAdapter(adapter);

        // Настройка списка проектов
        String[] projects = {"Проект А", "Проект Б", "Проект В"};
        ArrayAdapter<String> projectAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, projects);
        spinnerProject.setAdapter(projectAdapter);
        spinnerProject.setText(projects[0], false);

        btnLoadTeam.setOnClickListener(v -> {
            // Просто обновляем список (в реальности загружали бы по проекту)
            Toast.makeText(this, "Команда загружена", Toast.LENGTH_SHORT).show();
            // Можно было бы менять список в зависимости от выбранного проекта
        });

        btnAddMember.setOnClickListener(v -> {
            Toast.makeText(this, "Добавление сотрудника (заглушка)", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onEdit(Employee employee) {
        Toast.makeText(this, "Редактирование " + employee.getFullName(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDelete(Employee employee) {
        teamMembers.remove(employee);
        adapter.notifyDataSetChanged();
        Toast.makeText(this, employee.getFullName() + " удален", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onViewTasks(Employee employee) {
        Toast.makeText(this, "Задачи сотрудника " + employee.getFullName(), Toast.LENGTH_SHORT).show();
        // Здесь можно открыть активность со списком задач сотрудника
    }
}